package com.example.paterns.strategy.robot;


public interface RobotBehavior {
    public int moveCommand();
}
