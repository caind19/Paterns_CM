package strategy.pattern;


public class ConcreteStrategyTwo implements Strategy {
    @Override
    public String doSomething() {
        return "Concrete Strategy Two";
    }
}
