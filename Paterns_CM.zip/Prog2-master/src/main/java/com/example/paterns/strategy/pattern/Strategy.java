package strategy.pattern;


public interface Strategy {
    public String doSomething();
}
